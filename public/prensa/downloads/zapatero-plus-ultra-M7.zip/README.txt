Paquete de medición M7 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-7-entrada.json
  - caso.json
  - cribados/cribado-MCS-7.json
  - delta/D6→7.json
  - docs/sesiones/buffer-07.md
  - medicion/M7.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
