Paquete de medición M5 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-5-entrada.json
  - caso.json
  - cribados/cribado-MCS-5.json
  - delta/D4→5.json
  - docs/sesiones/buffer-05.md
  - medicion/M5.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
