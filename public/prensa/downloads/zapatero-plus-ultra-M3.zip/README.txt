Paquete de medición M3 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-3-entrada.json
  - caso.json
  - cribados/cribado-MCS-3.json
  - delta/D2→3.json
  - docs/sesiones/buffer-03.md
  - medicion/M3.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
