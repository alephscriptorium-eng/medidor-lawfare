Paquete de medición M4 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-4-entrada.json
  - caso.json
  - cribados/cribado-MCS-4.json
  - delta/D3→4.json
  - docs/sesiones/buffer-04.md
  - medicion/M4.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
