Paquete de medición M9 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-9-entrada.json
  - caso.json
  - cribados/cribado-MCS-9.json
  - delta/D8→9.json
  - docs/sesiones/buffer-09.md
  - medicion/M9.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
