Paquete completo del caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-1-entrada.json
  - buffers/MCS-2-entrada.json
  - buffers/MCS-3-entrada.json
  - buffers/MCS-4-entrada.json
  - buffers/MCS-5-entrada.json
  - buffers/MCS-6-entrada.json
  - buffers/MCS-7-entrada.json
  - buffers/MCS-8-entrada.json
  - buffers/MCS-9-entrada.json
  - caso.json
  - cribados/cribado-MCS-1.json
  - cribados/cribado-MCS-2.json
  - cribados/cribado-MCS-3.json
  - cribados/cribado-MCS-4.json
  - cribados/cribado-MCS-5.json
  - cribados/cribado-MCS-6.json
  - cribados/cribado-MCS-7.json
  - cribados/cribado-MCS-8.json
  - cribados/cribado-MCS-9.json
  - docs/sesiones/buffer-01.md
  - docs/sesiones/buffer-02.md
  - docs/sesiones/buffer-03.md
  - docs/sesiones/buffer-04.md
  - docs/sesiones/buffer-05.md
  - docs/sesiones/buffer-06.md
  - docs/sesiones/buffer-07.md
  - docs/sesiones/buffer-08.md
  - docs/sesiones/buffer-09.md
  - estado.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
