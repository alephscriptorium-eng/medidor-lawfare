Paquete de medición M8 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-8-entrada.json
  - caso.json
  - cribados/cribado-MCS-8.json
  - delta/D7→8.json
  - docs/sesiones/buffer-08.md
  - medicion/M8.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
