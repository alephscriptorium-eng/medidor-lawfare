Paquete de medición M2 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-2-entrada.json
  - caso.json
  - cribados/cribado-MCS-2.json
  - delta/D1→2.json
  - docs/sesiones/buffer-02.md
  - medicion/M2.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
