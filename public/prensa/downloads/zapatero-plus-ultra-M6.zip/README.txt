Paquete de medición M6 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-6-entrada.json
  - caso.json
  - cribados/cribado-MCS-6.json
  - delta/D5→6.json
  - docs/sesiones/buffer-06.md
  - medicion/M6.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
