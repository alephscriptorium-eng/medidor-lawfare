Paquete de medición M1 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - buffers/MCS-1-entrada.json
  - caso.json
  - cribados/cribado-MCS-1.json
  - delta/D0→1.json
  - docs/sesiones/buffer-01.md
  - medicion/M1.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
