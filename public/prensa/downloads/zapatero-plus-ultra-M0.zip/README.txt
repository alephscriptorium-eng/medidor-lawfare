Paquete de medición M0 — caso zapatero-plus-ultra
Motor Medidor de Lawfare v1.0.0
Licencia: GPL-3.0-or-later

Archivos incluidos:
  - caso.json
  - medicion/M0.json

Generado con medidor build. Fuente canónica: repositorio medidor-lawfare.
